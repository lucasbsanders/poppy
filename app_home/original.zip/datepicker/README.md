# datepicker
DatePicker for Kivy - Python 3.3+

It's only a modification of [KivyCalendar](https://bitbucket.org/xxblx/kivycalendar) working on Python 3.3+. 
Credits to  [Oleg Kozlov (xxblx)](https://xxblx.bitbucket.org)
